﻿namespace DependencyInjectionDemo.Logic;

public interface IDemoLogic
{
    int Value1 { get; }
    int Value2 { get; }
}